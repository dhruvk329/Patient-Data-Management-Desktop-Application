/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend;
import Backend.database_info;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 */
public class DB_Appointments {
    Connection con;
    ResultSet rs;
    PreparedStatement pst;
    
    private Integer ID;
    private String Name;
    private String Agenda;
    private String Time;
    private String Duration;
    private String Date;

   public DB_Appointments(){
       con=null;
       rs=null;
       pst=null;
   }
    
       
    public DB_Appointments(Integer ID, String Name, String Agenda, String Time, String Duration, String Date) {

    
        this.ID = ID;
        this.Name = Name;
        this.Agenda = Agenda;
        this.Time = Time;
        this.Duration = Duration;
        this.Date = Date;

    }
     public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }
     public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getAgenda() {
        return Agenda;
    }

    public void setAgenda(String Agenda) {
        this.Agenda = Agenda;
    }
    public String getTime() {
        return Time;
    }

    public void setTime(String Time) {
        this.Time = Time;
    }

    public String getDuration() {
        return Duration;
    }

    public void setDuration(String Duration) {
        this.Duration = Duration;
    }

    public String getDate(){
        return Date;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }
    
    public ArrayList<DB_Appointments> AppointmentList(){
        
        ArrayList<DB_Appointments> Appointment_list = new ArrayList<>();
        con = database_info.mycon();

        ResultSet rs;
        PreparedStatement pst;

               String query = "SELECT `ID`, `Name`, `Agenda`, `Time`, `Duration`, `Date` FROM `Appointments`;";
        
        try {
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
           
            DB_Appointments Appointment;
            while(rs.next()){
                Appointment = new DB_Appointments(rs.getInt("ID"), 
                                 rs.getString("Name"),
                                 rs.getString("Agenda"),
                                 rs.getString("Time"),
                                 rs.getString("Duration"),
                                 rs.getString("Date")
                        
                                         
                                 );
                Appointment_list.add(Appointment);
            }
        
        } catch (SQLException ex) {
            Logger.getLogger(DB_Appointments.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Appointment_list;
        
    }
    
    
    
    
     public static void insertAppointmnet(DB_Appointments Appointment) {
    Connection con = null;
    PreparedStatement pst = null;
    
    try {
        con = database_info.mycon();
        pst = con.prepareStatement("INSERT INTO `Appointments` (`Name`, `Agenda`, `Time`, `Duration`, `Date`) VALUES (?, ?, ?, ?, ?)");
        
        pst.setString(1, Appointment.getName());
        pst.setString(2, Appointment.getAgenda());
        pst.setString(3, Appointment.getTime());
        pst.setString(4, Appointment.getDuration());
        pst.setString(5, Appointment.getDate());
        



        if (pst.executeUpdate() != 0) {
            JOptionPane.showMessageDialog(null, "Appointment Scheduled");
        } else {
            JOptionPane.showMessageDialog(null, "Something went wrong");
        }
    } catch (SQLException ex) {
        Logger.getLogger(DB_Appointments.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
        try {
            if (pst != null) {
                pst.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(DB_Appointments.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
     public static void updateAppointment(DB_Appointments Appointment) {
    Connection con = database_info.mycon();
    PreparedStatement pst = null;
    
    try {
        pst = con.prepareStatement("UPDATE `Appointments` SET `Name`=?, `Agenda`=?, `Time`=?, `Duration`=?, `Date`=? WHERE `ID`=?");
        pst.setString(1, Appointment.getName());
        pst.setString(2, Appointment.getAgenda());
        pst.setString(3, Appointment.getTime());
        pst.setString(4, Appointment.getDuration());
        pst.setString(5, Appointment.getDate());
        pst.setInt(6, Appointment.getID()); 
        
        if (pst.executeUpdate() != 0) {
            JOptionPane.showMessageDialog(null, "Appointment Record Updated");
        } else {
            JOptionPane.showMessageDialog(null, "Something Wrong");
        }
    } catch (SQLException ex) {
        Logger.getLogger(DB_Appointments.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
        try {
            if (pst != null) {
                pst.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(DB_Appointments.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
     
         public static void deleteAppointment(Integer AppointmentId)
    {
        
        Connection con = database_info.mycon();
        PreparedStatement pst;
        
        try {
            pst = con.prepareStatement("DELETE FROM `Appointments` WHERE `ID` = ?");

            pst.setInt(1, AppointmentId);

            int YesOrNo = JOptionPane.showConfirmDialog(null,"Do You Really Want To Delete This Appointment","Delete User", JOptionPane.YES_NO_OPTION);
            if(YesOrNo == 0){
               
                if(pst.executeUpdate() != 0){
                   
                    JOptionPane.showMessageDialog(null, "Appointment Deleted");
                }
                else{
                    JOptionPane.showMessageDialog(null, "Something Wrong");
                }
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(DB_Appointments.class.getName()).log(Level.SEVERE, null, ex);
        }

        
    }

    
}
