/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend;
import Backend.database_info;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 */
public class DB_BMI {
    Connection con;
    ResultSet rs;
    PreparedStatement pst;
    
    private Integer ID;
    private String Name;
    private String Height;
    private String Weight;
    private String BMI;
    private String Condition;

   public DB_BMI(){
       con = null;
       rs = null;
       pst = null;
   }
    
    
    public DB_BMI(Integer ID, String Name, String Height, String Weight, String BMI, String Condition) {

    
        this.ID = ID;
        this.Name = Name;
        this.Height = Height;
        this.Weight = Weight;
        this.BMI = BMI;
        this.Condition = Condition;

    }
    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }
     public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getHeight() {
        return Height;
    }

    public void setHeight(String Height) {
        this.Height = Height;
    }
    public String getWeight() {
        return Weight;
    }

    public void setWeight(String Weight) {
        this.Weight = Weight;
    }

    public String getBMI() {
        return BMI;
    }

    public void setBMI(String BMI) {
        this.BMI = BMI;
    }

    public String getCondition() {
        return Condition;
    }

    public void setCondition(String Condition) {
        this.Condition = Condition;
    }
    
    public ArrayList<DB_BMI> BMIList(){
        
        ArrayList<DB_BMI> BMI_list = new ArrayList<>();
        con = database_info.mycon();

        ResultSet rs;
        PreparedStatement pst;

               String query = "SELECT `ID`, `Name`, `Height`, `Weight`, `BMI`, `Condition` FROM `BMI`;";
        
        try {
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
           
            DB_BMI BMI;
            while(rs.next()){
                BMI = new DB_BMI(rs.getInt("ID"), 
                                 rs.getString("Name"),
                                 rs.getString("Height"),
                                 rs.getString("Weight"),
                                 rs.getString("BMI"),
                                 rs.getString("Condition")
                        
                                         
                                 );
                BMI_list.add(BMI);
            }
        
        } catch (SQLException ex) {
            Logger.getLogger(DB_BMI.class.getName()).log(Level.SEVERE, null, ex);
        }
        return BMI_list;
        
    }
    
    
    
    
     public static void insertBMI(DB_BMI BMI) {
    Connection con = null;
    PreparedStatement pst = null;
    
    try {
        con = database_info.mycon();
        pst = con.prepareStatement("INSERT INTO `BMI` (`Name`, `Height`, `Weight`, `BMI`, `Condition`) VALUES (?, ?, ?, ?, ?)");
        
        pst.setString(1, BMI.getName());
        pst.setString(2, BMI.getHeight());
        pst.setString(3, BMI.getWeight());
        pst.setString(4, BMI.getBMI());
        pst.setString(5, BMI.getCondition());
        



        if (pst.executeUpdate() != 0) {
            JOptionPane.showMessageDialog(null, "BMI value added");
        } else {
            JOptionPane.showMessageDialog(null, "Something went wrong");
        }
    } catch (SQLException ex) {
        Logger.getLogger(DB_BMI.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
        try {
            if (pst != null) {
                pst.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(DB_BMI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
}