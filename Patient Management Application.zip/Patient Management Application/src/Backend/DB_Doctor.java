/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend;

import Backend.database_info;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 */
public class DB_Doctor {
    
    Connection con = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
    
    private Integer ID;
    private String Name;
    private String Username;
    private String Email;
    private String Phone;
    private String Password;
    
       public DB_Doctor(){}
       
        public DB_Doctor(Integer ID, String Name, String Username, String Email, String Phone, String Password) {

    
        this.ID = ID;
        this.Name = Name;
        this.Username = Username;
        this.Email = Email;
        this.Phone = Phone;
        this.Password = Password;

    }
    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }
     public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }
    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String Phone) {
        this.Phone = Phone;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }
    
    public ArrayList<DB_Doctor> DoctorList(){
        
        ArrayList<DB_Doctor> doctor_list = new ArrayList<>();
        con = (Connection) database_info.mycon();

        ResultSet rs;
        PreparedStatement pst;

               String query = "SELECT `ID`, `Name`, `Username`, `Email`, `Phone`, `Password` FROM `Doctor`;";
        
        try {
            pst = (PreparedStatement) con.prepareStatement(query);
            rs = pst.executeQuery();
           
            DB_Doctor doctor;
            while(rs.next()){
                doctor = new DB_Doctor(rs.getInt("ID"), 
                                 rs.getString("Name"),
                                 rs.getString("Username"),
                                 rs.getString("Email"),
                                 rs.getString("Phone"),
                                 rs.getString("Password")
                        
                                         
                                 );
                doctor_list.add(doctor);
            }
        
        } catch (SQLException ex) {
            Logger.getLogger(DB_Doctor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return doctor_list;
        
    }
    
    
    
    
     public static void insertDoctor(DB_Doctor doctor) {
    Connection con = null;
    PreparedStatement pst = null;
    
    try {
        con = database_info.mycon();
        pst = con.prepareStatement("INSERT INTO `Doctor` (`Name`, `Username`, `Email`, `Phone`, `Password`) VALUES (?, ?, ?, ?, ?)");
        
        pst.setString(1, doctor.getName());
        pst.setString(2, doctor.getUsername());
        pst.setString(3, doctor.getEmail());
        pst.setString(4, doctor.getPhone());
        pst.setString(5, doctor.getPassword());
        



        if (pst.executeUpdate() != 0) {
            JOptionPane.showMessageDialog(null, "Your Account has been Created!");
        } else {
            JOptionPane.showMessageDialog(null, "Something went wrong");
        }
    } catch (SQLException ex) {
        Logger.getLogger(DB_Doctor.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
        try {
            if (pst != null) {
                pst.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(DB_Doctor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
}

