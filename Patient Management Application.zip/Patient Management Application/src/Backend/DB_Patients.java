/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend;

import Backend.database_info;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 */
public class DB_Patients {

    Connection con = null;
    ResultSet rs = null;
    PreparedStatement pst = null;

    private Integer ID;
    private String Name;
    private String Age;
    private String Gender;
    private String Mobile;
    private String Address;
    private String Disease;

    public DB_Patients() {
    }

    public DB_Patients(Integer ID, String Name, String Age, String Gender, String Mobile, String Address, String Disease) {

        this.ID = ID;
        this.Name = Name;
        this.Age = Age;
        this.Gender = Gender;
        this.Mobile = Mobile;
        this.Address = Address;
        this.Disease = Disease;

    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getAge() {
        return Age;
    }

    public void setAge(String Age) {
        this.Age = Age;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getMobile() {
        return Mobile;
    }

    public void setMobile(String Mobile) {
        this.Mobile = Mobile;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Mobile) {
        this.Address = Address;
    }

    public String getDisease() {
        return Disease;
    }

    public void setDisease(String Disease) {
        this.Disease = Disease;
    }

    public ArrayList<DB_Patients> PatientList() {

        ArrayList<DB_Patients> patient_list = new ArrayList<>();
        con = database_info.mycon();

        ResultSet rs;
        PreparedStatement pst;

        String query = "SELECT `ID`, `Name`, `Age`, `Gender`, `Mobile`, `Address`, `Disease` FROM `Patients`;";

        try {
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();

            DB_Patients patient;
            while (rs.next()) {
                patient = new DB_Patients(rs.getInt("ID"),
                        rs.getString("Name"),
                        rs.getString("Age"),
                        rs.getString("Gender"),
                        rs.getString("Mobile"),
                        rs.getString("Address"),
                        rs.getString("Disease")
                );
                patient_list.add(patient);
            }

        } catch (SQLException ex) {
            Logger.getLogger(DB_Patients.class.getName()).log(Level.SEVERE, null, ex);
        }
        return patient_list;

    }

    public static void insertPatient(DB_Patients patient) {
        Connection con = null;
        PreparedStatement pst = null;

        try {
            con = database_info.mycon();
            pst = con.prepareStatement("INSERT INTO `Patients` (`Name`, `Age`, `Gender`, `Mobile`, `Address`, `Disease`) VALUES (?, ?, ?, ?, ?, ?)");

            pst.setString(1, patient.getName());
            pst.setString(2, patient.getAge());
            pst.setString(3, patient.getGender());
            pst.setString(4, patient.getMobile());
            pst.setString(5, patient.getAddress());
            pst.setString(6, patient.getDisease());

            if (pst.executeUpdate() != 0) {
                JOptionPane.showMessageDialog(null, "New Patient Added");
            } else {
                JOptionPane.showMessageDialog(null, "Something went wrong");
            }
        } catch (SQLException ex) {
            Logger.getLogger(DB_Patients.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (pst != null) {
                    pst.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(DB_Patients.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public static void updatePatient(DB_Patients patient) {
        Connection con = database_info.mycon();
        PreparedStatement pst = null;

        try {
            pst = con.prepareStatement("UPDATE `Patients` SET `Name`=?, `Age`=?, `Gender`=?, `Mobile`=?, `Address`=?, `Disease`=? WHERE `ID`=?");
            pst.setString(1, patient.getName());
            pst.setString(2, patient.getAge());
            pst.setString(3, patient.getGender());
            pst.setString(4, patient.getMobile());
            pst.setString(5, patient.getAddress());
            pst.setString(6, patient.getDisease());
            pst.setInt(7, patient.getID());

            if (pst.executeUpdate() != 0) {
                JOptionPane.showMessageDialog(null, "Patient Record Updated");
            } else {
                JOptionPane.showMessageDialog(null, "Something Wrong");
            }
        } catch (SQLException ex) {
            Logger.getLogger(DB_Patients.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (pst != null) {
                    pst.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(DB_Patients.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public static void deletePatient(Integer patientID) {

        Connection con = database_info.mycon();
        PreparedStatement pst;

        try {
            pst = con.prepareStatement("DELETE FROM `Patients` WHERE `ID` = ?");

            pst.setInt(1, patientID);

            // show a confirmation message before deleting the User
            int YesOrNo = JOptionPane.showConfirmDialog(null, "Do you really want to delete this patient?", "Delete Patient", 
                    JOptionPane.YES_NO_OPTION);
            if (YesOrNo == 0) {

                if (pst.executeUpdate() != 0) {

                    JOptionPane.showMessageDialog(null, "Patient Record Deleted");
                } else {
                    JOptionPane.showMessageDialog(null, "Something Wrong");
                }

            }

        } catch (SQLException ex) {
            Logger.getLogger(DB_Patients.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
