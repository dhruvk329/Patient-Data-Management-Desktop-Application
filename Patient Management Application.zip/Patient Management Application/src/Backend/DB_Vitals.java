/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend;
import Backend.database_info;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 */
public class DB_Vitals {
    Connection con = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
    
    private Integer ID;
    private String Name;
    private String BP1;
    private String BP2;
    private String BP3;
    private String SL1;
    private String SL2;
    private String SL3;
    private String SP1;
    private String SP2;
    private String SP3;
    
    public DB_Vitals(){}
    
    
    public DB_Vitals(Integer ID, String Name, String BP1, String BP2, String BP3, String SL1, String SL2, String SL3, String SP1, String SP2, String SP3) {

    
        this.ID = ID;
        this.Name = Name;
        this.BP1 = BP1;
        this.BP2 = BP2;
        this.BP3 = BP3;
        this.SL1 = SL1;
        this.SL2 = SL2;
        this.SL3 = SL3;
        this.SP1 = SP1;
        this.SP2 = SP2;
        this.SP3 = SP3;

    }
    


    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }
     public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getBP1() {
        return BP1;
    }

    public void setBP1(String BP1) {
        this.BP1 = BP1;
    }

    public String getBP2() {
        return BP2;
    }

    public void setBP2(String BP2) {
        this.BP2 = BP2;
    }

    public String getBP3() {
        return BP3;
    }

    public void setBP3(String BP3) {
        this.BP3 = BP3;
    }

    public String getSL1() {
        return SL1;
    }

    public void setSL1(String SL1) {
        this.SL1 = SL1;
    }
     public String getSL2() {
        return SL2;
    }

    public void setSL2(String SL2) {
        this.SL2 = SL2;
    }
     public String getSL3() {
        return SL3;
    }

    public void setSL3(String SL3) {
        this.SL3 = SL3;
    }
    public String getSP1() {
        return SP1;
    }

    public void setSP1(String SP1) {
        this.SP1 = SP1;
    }
     public String getSP2() {
        return SP2;
    }

    public void setSP2(String SP2) {
        this.SP2 = SP2;
    }
     public String getSP3() {
        return SP3;
    }

    public void setSP3(String SP3) {
        this.SP3 = SP3;
    }
    
     public ArrayList<DB_Vitals> VitalsList(){
        
        ArrayList<DB_Vitals> vitals_list = new ArrayList<>();
        con = database_info.mycon();

        ResultSet rs;
        PreparedStatement pst;

               String query = "SELECT `ID`, `Name`, `BP1`, `BP2`, `BP3`, `SL1`, `SL2`, 'SL3', 'SP1', 'SP2', 'SP3' FROM `Vitals`;";
        
        try {
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
           
            DB_Vitals vitals;
            while(rs.next()){
                vitals = new DB_Vitals(rs.getInt("ID"), 
                                 rs.getString("Name"),
                                 rs.getString("BP1"),
                                 rs.getString("BP2"),
                                 rs.getString("BP3"),
                                 rs.getString("SL1"),
                                 rs.getString("SL2"),
                                 rs.getString("SL3"),
                                 rs.getString("SP1"),
                                 rs.getString("SP2"),
                                 rs.getString("SP3")
                                         
                                 );
                vitals_list.add(vitals);
            }
        
        } catch (SQLException ex) {
            Logger.getLogger(DB_Vitals.class.getName()).log(Level.SEVERE, null, ex);
        }
        return vitals_list;
        
    }
    
    
    
    
     public static void insertVitals(DB_Vitals vitals) {
    Connection con = null;
    PreparedStatement pst = null;
    
    try {
        con = database_info.mycon();
        pst = con.prepareStatement("INSERT INTO `Vitals` (`Name`, `BP1`, `BP2`, `BP3`, `SL1`, `SL2`,`SL3`,`SP1`,`SP2`,`SP3`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        pst.setString(1, vitals.getName());
        pst.setString(2, vitals.getBP1());
        pst.setString(3, vitals.getBP2());
        pst.setString(4, vitals.getBP3());
        pst.setString(5, vitals.getSL1());
        pst.setString(6, vitals.getSL2());
        pst.setString(7, vitals.getSL3());
        pst.setString(8, vitals.getSP1());
        pst.setString(9, vitals.getSP2());
        pst.setString(10, vitals.getSP3());

        if (pst.executeUpdate() != 0) {
            JOptionPane.showMessageDialog(null, "New Vital Added");
        } else {
            JOptionPane.showMessageDialog(null, "Something went wrong");
        }
    } catch (SQLException ex) {
        Logger.getLogger(DB_Vitals.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
        try {
            if (pst != null) {
                pst.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(DB_Vitals.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

  

        
    }



   

   
    


    

