/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Frontend;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

/**
 *
 * 
 * 
 */

class Chat_Bot_Screen extends JFrame {
    
    
    
    private JTextArea chat_screen = new JTextArea();
    private JTextArea chat_type = new JTextArea();
    private JButton send_button  = new JButton();
    private JLabel send_label = new JLabel();
    
    Chat_Bot_Screen(){ 
     JFrame chat_bot = new JFrame();
     chat_bot.setDefaultCloseOperation(EXIT_ON_CLOSE);
     chat_bot.setVisible(true);
     chat_bot.setResizable(false);
     chat_bot.setLayout(null);
     chat_bot.setSize(400,400);
     chat_bot.getContentPane().setBackground(Color.yellow);
     chat_bot.setTitle("Chatbot");
     chat_bot.add(chat_screen);
     chat_bot.add(chat_type);
     chat_screen.setSize(320,310);
     chat_screen.setLocation(1,1);
     chat_screen.setBackground(Color.BLACK);
     chat_type.setSize(300,20);
     chat_type.setLocation(1,320);
     chat_bot.add(send_button);
     send_label.setText("Send");
     send_button.add(send_label);
     send_button.setSize(400,20);
     send_button.setLocation(300,320);
     
     send_button.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
             
             if(e.getSource()==send_button){
                 String text = chat_type.getText().toLowerCase();
                 chat_screen.setForeground(Color.ORANGE);
                 chat_screen.append("You-->" +text+"\n");
                 chat_type.setText("");
if (text.contains("hi")) {
    chatreply("Hi there");
} else if (text.contains("how to save and generate patient vital graphs?")) {
    chatreply("From the record patient vital screen");
} else if (text.contains("how to print list of patients?")) {
    chatreply("From the patient registration form");
 } else if (text.contains("can i generate prescriptions?")) {
    chatreply("Yes you can!"); 
     } else if (text.contains("can i delete a patient from the database?")) {
    chatreply("Yes you can!"); 
         } else if (text.contains("are the BMI readings saved to the database?")) {
    chatreply("Yes, both to the database and JTable!"); 
} else {
    chatreply("I am not sure I understand");
}

                 
                 
                 
     
                 
                 
             }
             
         }
     });
     
     
 }
    public void chatreply(String s){
        chat_screen.append("Chatbot -->"+s+"\n");
    }
   
    
}
public class Chat_Bot {
    public static void main(String[] args){
        new Chat_Bot_Screen();
    }
    
}
