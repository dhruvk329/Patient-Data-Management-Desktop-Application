/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Patient_Management_Application;

import Frontend.Welcome_Screen;

/**
 *
 * @author amankhera
 */
public class Patient_Management_Application {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Welcome_Screen form = new Welcome_Screen() ; // creates a nnew Log In JFrame
        form.setVisible (true); // displays log in jFrame
    }
        
        // TODO code application logic here
    }
    

